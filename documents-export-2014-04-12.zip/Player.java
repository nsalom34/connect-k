/** 
 * This class represents a single human player playing Connect Four.  The 
 * class keeps track of the player's name and their disk character.
 * 
 * STUDENTS MUST IMPLEMENT AND SUBMIT THIS FILE
 */
public class Player 
{
	/*
	 *  TODO REMOVE ALL "TODO" COMMENTS AFTER YOU COMPLETE THE TASKS.
	 *  DON'T TURN IN A PROGRAM WITH ANY OF THESE "TODO" COMMENTS.
	 */
	
	// TODO DECLARE ALL PRIVATE INSTANCE VARIABLES
	private String name; 
	private char disk; // X =player 1, O= player 2
	
	/**
	 * A constructor to create a new player.  It takes as arguments the
	 * new player's name and disk character and uses these parameter values
	 * to initialize the corresponding class variables.
	 * 
	 * @param name the player's name
	 * @param disk the character representing this player's disks
	 */
	public Player(String name, char disk)
	{
		// TODO INITIALIZE PRIVATE INSTANCE VARIABLES
		this.name=name; 
		this.disk=disk;
	}
	
	/**
	 * Getter method which returns the player's name as a String
	 * @return The player's name
	 */
	public String getName()
	{
		// TODO IMPLEMENT THIS METHOD
		return this.name; 
	}
	
	/**
	 * Getter method which returns the player's disk type as a char
	 * @return The player's disk character
	 */
	public char getDisk()
	{
		// TODO IMPLEMENT THIS METHOD
		return  this.disk;
	}


//	/**
//	 * Students may implement the toString method if they wish.
//	 */
//	public String toString() {
//		// OPTIONAL: Students may uncomment and implement this method
//	    // if they wish to.
//	}
		
}
