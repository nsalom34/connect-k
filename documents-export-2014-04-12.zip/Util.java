import java.awt.Dimension;

/** 
 * Contains the static constant values used by the program as well as methods
 * for interacting with the GUI -- STUDENTS DO NOT EDIT OR SUBMIT THIS CLASS.
 *
 *@author matthewb - matthewb@cs.wisc.edu
 */
public class Util 
{
	/**
	 * Default player names for first game.  Will also store latest
	 * player names to have those become the default player names for next game.
	 * Students should not edit this file as it will not be handed in.
	 */
	public static String[] DEFAULT_PLAYER = { 
		"Justin Bieber",            // player 1 
		"Arnold Schwarzenegger"     // player 2
	};
	
	/** 
	 * The characters that represent players in the console printed version
	 * of the GameGrid.
	 */
	public static final char[] PLAYER_CHAR = { 'X', 'O' };

	/**
	 * Maximum height and width of the grid
	 */
	public static final int MAX_SIZE = 30;
	
	/**
	 * Minimum height and width of the grid
	 */
	public static final int MIN_SIZE = 1;
	
	/**
	 * Character representing an empty slot in the game
	 */
	public static char EMPTY_SLOT = '.';
	
	/**
	 * The instance of the GUI
	 */
	private static Gui gui;


	/**
	 * Update the GUI window.  The GUI will read data from the ConnectK's 
	 * "game" variable in order to perform this update.
	 */
	public static void updateGUI()
	{
		gui.updateCanvas();
		gui.updateTurnLabel();
	}	

	
	/**
	 * Destroy the GUI.  This should be called from the ConnectK's 
	 * launchGameWithParameters method before creating a new GameGrid instance.
	 */
	public static void destroyGUI()
	{
		if (Util.gui != null) 
		{
			Util.gui.dispose();
			gui = null;
		}
	}

	/**
	 * Builds and initializes a new GUI window.
	 */
	public static void buildGUI(ConnectK k)
	{
		gui = new Gui();
		gui.init(k);
    	updateGUI();
	}

	/**
	 * Opens up a modal window that prompts the user to enter new settings for 
	 * the next game.
	 * 
	 * @param message the message that pops up as the title to the modal window.
	 * This message should display "Player X won!" if a player named "X" won the
	 * game.  If a tie occurred, this message should display "The grid is full. 
	 * Tie game!"
	 */
	public static void showNewGameDialog(String message)
	{
		StartupDialog sDialog = new StartupDialog(message);
		sDialog.setPreferredSize(new Dimension(350, 250));
		sDialog.pack();
		sDialog.setVisible(true);		
	}
}
