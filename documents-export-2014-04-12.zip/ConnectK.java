/**
 * This class represents a game of Connect K between two players.  It is 
 * in charge of managing each player's turn, managing a GameGrid object, and
 * checking for a winner (or a tie game). 
 * 
 * STUDENTS MUST IMPLEMENT AND SUBMIT THIS FILE
 */
public class ConnectK  // DEB'S SOLUTION
{	
	/*
	 *  TODO REMOVE ALL "TODO" COMMENTS AFTER YOU COMPLETE THE TASKS.
	 *  DON'T TURN IN A PROGRAM WITH ANY OF THESE "TODO" COMMENTS.
	 */

	/** 
	 * Constructor that creates a ConnectK instance with the specified
	 * properties.
	 * 
	 * @param p1Name Name of the first player.
	 * @param p2Name Name of the second player.
	 * @param rows The number of rows from bottom to top in game grid.
	 * @param cols The number of columns from left to right in game grid.
	 * @param K The number of disks of the same color that must be
	 * placed in a row to win a game of ConnectK.  (The K value)
	 */
	public ConnectK(String p1Name, String p2Name, int rows, int cols,
			int K) 
	{
		// REALLY BIG HINT:
		// ITS A GOOD IDEA TO CREATE AND ASSIGN TO AN INSTANCE FIELD
		// FOR A GAMEGRID object here.

	}
	
	/**
	 * Allows the GUI to get the GameGrid instance needed for display.
	 * @return The GameGrid
	 */
	public GameGrid getGameGrid() 
	{ 
		// TODO RETURN THE GAMEGRID OBJECT THAT THIS CONNECTK 
		// INSTANCE MANAGES.  
		// Easy, if you created and assigned such an object in the constructor.
	}


	/**
	 * This method is called when the submit button is clicked in the Startup
	 * Dialog so long as the input is validated by the validateSetupInput
	 * method.  This method is responsible for destroying the old GUI window
	 * (if it exists), setting the "game" variable to a new GameGrid instance,
	 * and building a new GUI window.
	 * 
	 * @param p1Name the first player's name
	 * @param p2Name the second player's name
	 * @param rows the number of rows in the new game's grid
	 * @param cols the number of columns in the new game's grid
	 * @param K the number of disks to connect in order to achieve victory
	 */
	public static void launchGameWithParameters(String p1Name, 
			String p2Name,
			int rows, 
			int cols, 
			int K)
	{
		// BE SURE TO CHECK OUT THE UTIL class.  THERE ARE METHODS THERE
		// THAT WILL DO PARTS OF THIS METHOD.  JUST CALL THEM IN THE RIGHT
		// ORDER WITH THE RIGHT ARGUMENTS.
		
		
		
		// 1. DESTROY THE OLD GUI WINDOW
		

		// 2. CREATE A NEW CONNECTK object using specified parameter values.
		

		// 3. BUILD THE NEW GUI WINDOW with the ConnectK object just created
		
	}

	/**
	 * <p>
	 * This method is called when the "Submit" button is pressed in the Startup
	 * Dialog.  This method is responsible for validating the data from the 
	 * from the Startup Dialog.
	 * </p>
	 * 
	 * <p>
	 * This method receives the values entered by the user in the window and 
	 * should make sure that the number of rows, columns, and connection number
	 * are valid.
	 * </p>
	 * 
	 * <p>
	 * A row/column number is invalid if it is less than the MIN_SIZE value in
	 * the Util class OR if it is greater than the MAX_SIZE value in the Util 
	 * class.
	 * <br />
	 * <br /> 
	 *  If the row number is too large it should return the message:
	 * <br>
	 * <br>
	 * "Number of rows must be less than or equal to <MAX_SIZE>"
	 * <br>
	 * <br>
	 * If the row number is too small, it returns the message:
	 * <br>
	 * <br>
	 * "Number of rows must be greater than or equal to <MIN_SIZE>" 
	 * <br>
	 * <br>
	 *  If the column number is too large it should return the message:
	 * <br>
	 * <br>
	 * "Number of columns must be less than or equal to <MAX_SIZE>"
	 * <br>
	 * <br>
	 * If the column number is too small, it returns the message:
	 * <br>
	 * <br>
	 * "Number of columns must be greater than or equal to <MIN_SIZE>" 
	 * <br>
	 * <br>
	 * We put the "MAX_SIZE" in angle brackets to denote that this value 
	 * must be the actual value stored in the Util class.
	 * <br>
	 * <br>
	 * The connect number is invalid if it is less than the MIN_SIZE value in
	 * the Util class OR if it is larger than the minimum of the two numbers:
	 * number of rows and number of columns. 
	 * <br>
	 * <br>
	 * For example, if the connect number is too small, this method returns 
	 * the message:
	 * <br>
	 * <br>
	 * "Connect length must be greater than or equal to <MIN_SIZE>"
	 * <br>
	 * <br>
	 * This method should check these values in the following order:
	 * <ul>
	 * <li> 1. rows </li>
	 * <li> 2. columns </li>
	 * <li> 3. connect </li>
	 *  
	 * @param rows the number of rows
	 * @param cols the number of cols
	 * @param connect the connect length
	 * @return an appropriate error message if any of these values are invalid.
	 * If all of the values are valid, this method returns null.  The message
	 * returned by this method will appear as an error message in the Startup
	 * Dialog.
	 */
	public static String validateSetupInput(int rows, int cols, int connect)
	{
		// TODO CHECK IF NUM ROWS IS VALID. IF NOT, RETURN APPROPRIATE MESSAGE
		
		// TODO CHECK IF NUM COLS IS VALID. IF NOT, RETURN APPROPRIATE MESSAGE 
		
		// TODO DETERMINE MINIMUM OF ROWS AND COLUMNS
		
		/*
		 *  TODO CHECK IF CONNECT SIZE IS MORE THAN THE Util.MIN_SIZE
		 *  and LESS THAN OR EQUAL TO THE MINIMUM ROWS AND COLUMNS VALUE.
		 *  IF NOT, RETURN APPROPRIATE MESSAGE.
		 */
		
		// TODO IF INPUT IS VALID, RETURN NULL

		
	}

	/**
	 * When a player clicks on a column in the GUI, the GUI calls this method 
	 * and passes the index of the column that the player clicked.  
	 * 
	 * This method attempts to place the current player's disk into the 
	 * selected column.  In some cases the GUI display must be updated.
	 * In all cases a message is returned indicating what happened.
	 * If the game is won or the grid is full, a new dialog will be 
	 * opened allowing the user to start a new game.    
	 * 
	 * <p>Step 1) If the column is full, the disk is not placed and this 
	 * message is returned:</p>
	 * 
	 *  "This column is full! Try again."
	 * 
	 * <p>Step 2) If the column was not full, the disk is placed 
	 * in the next empty slot of the column.</p>
	 * 
	 * <p>After the disk is placed, perform these checks to determine
	 * what message to return.</p>
	 * 
	 * <p>Step 3) CHECK FOR WIN: If a win is detected:</p>
	 *  1. Set the message to: "Player <X> won!"
	 *  2. update the GUI (by calling the Util's "updateGUI" method)<br>
	 *  3. WAIT TO CREATE THE NEW GUI (until step 5)
	 * 
	 * <p>Step 4) CHECK FOR TIE: If no win and the grid is full, it's a tie.
	 * Do the following:</p>
	 * 
	 *  1. Set the return message to "The grid is full. Tie game!" 
	 *  2. update the GUI (by calling the Util's "updateGUI" method)<br>
	 *  3. WAIT TO CREATE THE NEW GUI (until step 5)
	 *  
	 * <p>Step 5) If game is not won and is not tied (grid full):
	 * 
	 *  1. Set the return message to: "Disk successfully placed in column <X>."
	 *  2. advance the turn to the next player
	 *  3. update the GUI (by calling the Util's "updateGUI" method)
	 *  
	 *  <p>Step 6) If this game is DONE (won or grid full)
	 *  
	 *   1. Start next game by calling: Util.showNewGameDialog(message);
	 * 
	 * @param column the column to place the disk
	 * @return the message describing the result of this action
	 */
	public String placeDisk(int column)
	{	
		// ATTEMPT TO PLACE CURRENT PLAYER'S DISK INTO TARGET COLUMN

		// IF COLUMN IS FULL, RETURN APPROPRIATE MESSAGE

		// IF COLUMN NOT FULL, PLACE DISK AND CHECK FOR WIN

		/*
		 * CHECK IF THIS DISK RESULTED IN A WIN.  IF GAME WON:
		 * 
		 * 1. SET THE GAME MESSAGE TO "player_name won!"
		 * 2. UPDATE THE GUI
		 */

		// IF GAME NOT WON, CHECK FOR TIE

		/*
		 * CHECK IF THIS DISK RESULTED IN A TIE (and not a win):
		 * 
		 * 1. SET THE GAME MESSAGE TO "The grid is full. Tie game!"
		 * 2. UPDATE THE GUI
		 */

		// IF GAME NOT WON AND GRID IS NOT FULL:
		// ADVANCE TO THE NEXT PLAYER'S TURN 
		// UDPATE THE GUI
		// RETURN THIS MESSAGE, where X is the column index:
		//  "Disk successfully placed in column X."
		
		/*
		 * IF THIS GAME WAS WON or GRID IS FULL:
		 * NOW, WE CAN START A NEW GAME (and GUI).
		 * 
		 *  1. Util.showNewGameDialog(return_message_set_earlier_in_method)
		 *  2. RETURN THE MESSAGE (won or tie message from above)
		 */

	}
	
	/**
	 * The main method.  The program's execution begins here!
	 * This methods just gets the GUI started by calling the
	 * Util.showNewGameDialog() method.
	 * 
	 * DO NOT CHANGE THIS METHOD.
	 * 
	 * @param args command line arguments (these aren't used in this program)
	 */
	public static void main(String[] args)
	{
		/*
		 * When the program first starts up, this command is called and brings
		 * up the Startup Dialog with the title "Welcome to ConnectK!".   
		 */
		Util.showNewGameDialog("Welcome to ConnectK!");
	}


}
