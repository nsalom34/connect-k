/** 
 * This class represents a single column of disks in the Connect K game
 * grid.  Each column stores its total height along with the current number
 * of disks in the column.  Each column also stores an array of char values
 * that represent the disks (and empty spaces) in the column.
 * <p>
 * Player characters and empty slot characters are defined in  
 * {@link Util}
 * 
 * STUDENTS MUST IMPLEMENT AND SUBMIT THIS FILE
 */
public class Column 
{	
    /*
     *  TODO REMOVE ALL "TODO" COMMENTS AFTER YOU COMPLETE THE TASKS.
     *  DON'T TURN IN A PROGRAM WITH ANY OF THESE "TODO" COMMENTS.
     */

    // TODO DEFINE PRIVATE INSTANCE VARIABLES
	private int colHeight;
	private int numDisks;
	public char [] diskArray;
	private int location = 0;
	
	/**
	 * A constructor which takes the height of the new column object as an 
	 * argument and uses it to create a disks array of that length.  The array
	 * is initialized to contain all '.' characters and the colHeight
	 * and numDisks variables are initialized to height and 0 respectively.
	 */
	public Column(int height)
	{
		diskArray = new char [height];
				
		for (int i = 0; i<height; i++){
			this.diskArray [i] = '.';
		}
		
		this.colHeight = height;
		this.numDisks = 0;
		

	}
	
	/**
	 * Attempts to add a disk represented by the char parameter disk to this
	 * column.  Calls isFull() to determine if space exists in the column
	 * and only adds the new disk if there is room, incrementing numDisks
	 * if necessary.
	 * 
	 * @param disk a char representing the disk to be added
	 */
	public void addDisk(char disk)
	{
		if (isFull()){
			
		}
		else {
			this.diskArray [location] = disk;
			location ++;
		}
	}
	
	/**
	 * Get a disk at a given row of this column. Does not handle invalid
	 * rows as they can never occur.
	 * 
	 * @param row the row (index) from which to retrieve the disk
	 * @return the disk at the specified row
	 */
	public char getDiskAt(int row)
	{
		return this.diskArray [row];
		 
	}
	
	/**
	 * Tests if this column is filled with disks.
	 * @return true if the column is full. false otherwise.
	 */
	public boolean isFull()
	{
		for (int i = 0; i < colHeight; i++ ){
			if (this.diskArray [i] == '.'){
				return false;
				}
			else{
				}
			}
	
		return true;
	}
	
	/*public static void main (String[] Args ){
		
		Column c1 = new Column(5);
		for (int i = 0; i<0 ; i++){
			System.out.println(c1.diskArray[i]);
		}*/
		
	}

//	/**
//	 * Students may implement the toString method if they wish.
//	 */
//	public String toString() {
//		// OPTIONAL: Students may uncomment and implement this method
//	    // if they wish to.
//	}
	

