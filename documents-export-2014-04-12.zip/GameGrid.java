
/** 
 * This class represents the game grid in a game of Connect K.  It manages
 * an array of the Column objects that store the game's disks as well as 
 * keeping track of the size of the playing space and the number of sequential
 * disks required to win.
 * 
 * To make some other aspects of our GUI solution, we also have our 
 * GameGrid know how many disks in a row it takes to win, as well as 
 * who the players are, and if the grid is full.  
 * 
 * TODO: IMPLEMENT ALL METHODS AS DESCRIBED.  ADD YOUR OWN PRIVATE METHODS
 * IF YOU LIKE.
 * 
 * STUDENTS MUST IMPLEMENT AND SUBMIT THIS FILE
 */
public class GameGrid 
{	
	private int row;
	private int col;
	private int k;
	private Column [] gride;
	private Player p1;
	private Player p2;
	private boolean firstTurn;

	/**
	 * The constructor takes as arguments the game grid size parameters.
	 * It creates a GameGrid object based on the parameters for the size
	 * of the grid.  It also creates the two Player objects.
	 * 
	 * @param p1Name the name of the first player
	 * @param p2Name the name of the second player
	 * @param rows the height of each Column in the game grid for this game
	 * @param cols the number of Column objects making up the game grid for 
	 * this game
	 * @param K the length of the sequence of disks needed for a 
	 * player to win the game.
	 */
	public GameGrid(String p1Name, 
			String p2Name, 
			int rows, 
			int cols, 
			int K)
	{
		p1 = new Player(p1Name, 'X');
		p2 = new Player(p2Name, 'O');
		
		this.row = rows;
		this.col = cols;
		this.k = K;
		firstTurn = true;
		
		Column [] gride  = new Column [cols];
		for (int i = 0; i<cols; i++){
			gride [i] = new Column(rows);
		}

		
		// SAVE NUMBER OF ROWS

		// SAVE NUMBER OF COLS

		// CREATE AND INITIALIZE COLUMNS 

		// CREATE AND INITIALIZE PLAYERS

		// INITIALIZE FIRST TURN

		// INITIALIZE LENGTH OF SEQUENCE TO WIN
		
	}
	

	/**
	 * @return the player whose current turn it is
	 */
	public Player getCurrentPlayer()
	{
		if (firstTurn){
			return p1;
			
			}else{
				
			return p2;
			}
		
	}

	/**
	 * Returns the name of the specified player. 
	 * 
	 * THE UTIL CLASS WILL USE CURRENT PLAYER NAMES AS DEFAULT NAMES FOR 
	 * NEW GAMES AFTER THE FIRST GAME IS PLAYED. THIS METHOD MUST BE 
	 * IMPLEMENTED FOR THAT TO OCCUR.
	 * 
	 * getPlayerName(1) must return the name of the first player.
	 * getPlayerName(2) must return the name of the second player.
	 * 
	 * Other player numbers do not have to be considered.
	 * 
	 * @param playerNum 1  or 2 to indicate which player name should be returned.
	 * @return the name of the player.
	 */
	public String getPlayerName(int playerNum)
	{
		if (playerNum == 1){
			return p1.getName();
			
			}else{
				
			return p2.getName();
			}	
		}

	/**
	 * @return the number of columns in this game grid
	 */
	public int getNumColumns()
	{
		return row;
	}

	/**
	 * @return the number of rows in each column of this game grid
	 */
	public int getNumRows()
	{
		return col;
	}

	/**
	 * @return an array containing all of the column objects in this grid.
	 * Do not create a new array on each call to this method, 
	 * as our GUI only calls this once for each new game and 
	 * uses that reference through a game.
	 */
	public Column[] getColumns()
	{
		return gride;
	}

	/**
	 * @return the number in a row needed to win this game.
	 */
	public int getK() {
		return k;
	}

	/**
	 * This method determines if game grid contains a winning sequence of 
	 * the given Player disks.
	 * 
	 * Also, sets the state of this game grid, if a winner is found.
	 * Thus, if isWinner() returns true, the isWon() method must also return 
	 * true.
	 * 
	 * @param toCheck the Player whose disks should be checked for a winning 
	 * sequence
	 * @return true if the Player has won, false otherwise
	 */
	public boolean isWinner(Player toCheck)
	{
		
		char disk = toCheck.getDisk();
		for (int i = 0; i<row; i++){
			
		if (checkColumn (gride[i] , disk)) {
			return true;
		}else{
			
		}
		
		}
		return false;
		// HINT: YOU MAY WISH TO DEFINE YOUR OWN PRIVATE METHODS
		// TO SOLVE PARTS OF THIS METHODS WORK
		

		// CHECK FOR A WIN IN ANY COLUMN
		// ------------
		// | ...  X ...
		// | ...  X ...
		// | ...  X ...
		
		// CHECK FOR A WIN IN ANY ROW
		// ------------
		// | ... ... ...
		// | ... XXX ...
		// | ... ... ...
		
		// CHECK FOR A WIN IN DIAGONAL UP FROM ANY LEFT TO RIGHT
		// ------------
		// | ..X ...
		// | .X. ...
		// | X.. ...

		// CHECK FOR A WIN IN DIAGONAL UP FROM ANY BOTTOM TO TOP
		// ------------
		// | ... ..X ...
		// | ... .X. ...
		// | ... X.. ...

		// CHECK FOR A WIN IN DIAGONAL DOWN FROM ANY LEFT TO RIGHT
		// ------------
		// | X.. ...
		// | .X. ...
		// | ..X ...

		// CHECK FOR A WIN IN DIAGONAL DOWN FROM ANY TOP TO BOTTOM
		// ------------
		// | ... X.. ...
		// | ... .X. ...
		// | ... ..X ...

		// RETURN RESULTS true if win was detected, other wise false.

	}
	
	/**
	 * Returns true if this game has been won.
	 * Used by ConnectK to determine, if a new game can be started.
	 * 
	 * If isWinner() returned true, this method must also return true
	 * indicating the game is done and someone has already won.
	 * 
	 * @return false if no player has won this game grid yet.
	 */
	public boolean isWon() {
		return false;
		// TODO IMPLEMENT THIS METHOD
	}

	/**
	 * Checks to see if the entire game grid is filled with disks.
	 * This method goes through all column.  If all of them are full, this 
	 * method returns true.
	 * 
	 * @return false if any column is not full, otherwise returns true
	 */
	public boolean isFull()
	{
		return false;
		// TODO IMPLEMENT THIS METHOD
	}

	/**
	 * Advances the turn to the next player's turn.
	 */
	public void advanceTurn()
	{
		if(firstTurn){
			firstTurn = false;
		}else{firstTurn = true;}
}

	/**
	 * This method attempts to add a disk represented by the char disk 
	 * parameter to the column at the index specified by the int column
	 * parameter.  
	 * 
	 * If the column is not full, the disk is added and this 
	 * method returns true, otherwise the disk is not added and the 
	 * method returns false.
	 * 
	 * @param column the index of the column in which to attempt to place the 
	 * disk
	 * @param disk the character representing the disk to be placed
	 * @return true if the disk was successfully placed.  False if the 
	 * specified column was full and the disk was unable to be placed.
	 */
	public boolean addDiskToColumn(int column, char disk)
	{
		return true;
		// TODO TRY ADDING DISK TO TARGET COLUMN
		// TODO RETURN RESULT OF THIS ACTION
		// true if added successfully, otherwise returns false
	}

	/**
	 * This method should return a String representation of the game grid.
	 * Each character in each column should be printed followed by a space
	 * and the output should be arranged so that the element in the first
	 * index of the first Column appears in the bottom left corner of the 
	 * printed grid.  On the line below each column of the printed grid 
	 * should be the corresponding index of that column.
	 * 
	 * @return the String representation of the grid
	 */
	/*@Override
	public String toString()
	{
		// TODO CREATE THE STRING REPRESENTATION OF THIS GAMEGRID OBJECT
	}
	*/
	private boolean checkColumn (Column c, char disk){
		
		for (int i = 0; i<c.diskArray.length - 1 ; i++){
			if (c.diskArray[i] == c.diskArray[i+1] && c.diskArray[i+1] == 
					c.diskArray[i+2] && c.diskArray[i] == disk){
				return true;
			}else{
				
			}

		}return false;
	}

}
